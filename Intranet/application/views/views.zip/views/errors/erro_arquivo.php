<?php include '../template/begin.php'; ?>


<div alert alert-danger>
    <h1 class="error"><i class="glyphicon glyphicon-warning-sign"></i> <small>Cadastro Incorreto</small> </h1>
</div>

<div class="alert alert-danger" style="width: 100%">
      <?php echo '<b style="font-size:14px">'.$erro.'</b></div> 
<a href="javascript:window.history.go(-1);" class="btn btn-default">Voltar</a>';exit;;?>







<?php include '../template/end.php'; ?>