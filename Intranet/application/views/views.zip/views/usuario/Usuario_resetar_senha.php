<?php include '../template/_begin_intranet.php'; ?> 


<script>
    
    $( document ).ready(function() {
        if('<?=$erro?>' == '2'){
            $('#usuario_login').hide();
            $('#btn_renovar').hide();
        }
    });
    
    function submeter() {
        if ($('#usuario_login').val() == '') {
            alert('Login em branco');
            $('#usuario_login').focus();
            return false;
        }
        
        
       
 
        $('#form').submit();
    }
</script>
<body style="background:#F7F7F7;">

    <div class="">
        <a class="hiddenanchor" id="toregister"></a>
        <a class="hiddenanchor" id="tologin"></a>
        <div id="wrapper">
            <div id="login" class="animate form">
                <section class="login_content"> 
                    <form id="form" method="post" action="<?= $action ?>">
                        <h1 style=''>Renovar senha</h1>
                        
                        <?php if(!empty($this->session->userdata('message'))){ ?>
                        <div class="alert alert-<?=$aviso_class?>" role="alert"  >
                          <strong> <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?></strong> 
                        </div> 
                        <?php } ?>
                        <div>
                            <input type="text" class="form-control" placeholder="usu�rio" required="" id="usuario_login" name="usuario_login" onPaste='return false'/>
                        </div>
                        <div> 
                            <input id='btn_renovar' type="button" class="btn btn-danger" value="Renovar Senha" onclick="submeter()">
                            <a href="<?=site_url('usuario/')?>">
                                <input type="button" class="btn btn-default" value="Voltar" >
                            </a> 
                        </div>
                        <div class="clearfix"></div>
                        <div class="separator"> 
                            <!--p class="change_link">New to site?
                                <a href="#toregister" class="to_register"> Create Account </a>
                            </p-->
                            <div class="clearfix"></div>
                            <br />
                            <div>
                                <h1><i class="glyphicon glyphicon-leaf green" style="font-size: 26px;"></i> PORTAL SDR!</h1>

                                <a href='https://www.portalsdr.ba.gov.br/' target='_blank' >
                                    <p><b>SDR</b> - Secretaria de Desenvolvimento Rural</p>
                                </a>
                            </div>
                        </div>
                    </form>
                    <!-- form -->
                </section>
                <!-- content -->
            </div>

        </div>
    </div>

</body>
<?php include '../template/_end.php'; ?>