<?php include '../template/_begin_intranet.php'; ?> 


<script>
    function submeter() {
        if ($('#usuario_login').val() == '') {
            alert('Login em branco');
            $('#usuario_login').focus();
            return false;
        }
        if ($('#usuario_senha').val() == '') {
            alert('Senha em branco');
            $('#usuario_senha').focus();
            return false;
        }

        $('#form').submit();
    }
    /*
    $('#usuario_login').keypress(function(e) {
        alert(e.which)
        if(e.which === 13) {
            alert()
            return false;
        }
    });
    
    
    function valida_enter(valor){
        var usuario_login = $('#usuario_login').val();
        alert(usuario_login)
    }*/
</script>
<body style="background:#F7F7F7;">

    <div class="">
        <a class="hiddenanchor" id="toregister"></a>
        <a class="hiddenanchor" id="tologin"></a>
        <div id="wrapper">
            <div id="login" class="animate form">
                <section class="login_content"> 
                    <form id="form" method="post" action="<?= $action ?>">
                        <h1>LOGIN</h1>
                        <?php if(!empty($msg_erro)){ ?>
                        <div class="alert alert-danger" role="alert">
                          <strong> <?php echo $msg_erro ?></strong> 
                        </div> 
                        <?php } ?>
                        <div>
                            <input type="text" class="form-control" placeholder="Username" required="" id="usuario_login" name="usuario_login" />
                        </div>
                        <div>
                            <input type="password" class="form-control" placeholder="Password" required=""  id="usuario_senha" name="usuario_senha" />
                        </div>
                        <div>
                            <input type="button" class="btn btn-primary" value="Logar" onclick="submeter()">
                            <a href="<?=site_url('usuario/resetar_senha')?>">
                                <input type="button" class="btn btn-danger" value="Esqueci minha senha" >
                            </a> 
                        </div>
                        <div class="clearfix"></div>
                        <div class="separator"> 
                            <!--p class="change_link">New to site?
                                <a href="#toregister" class="to_register"> Create Account </a>
                            </p-->
                            <div class="clearfix"></div>
                            <br />
                            <div>
                                <h1><i class="glyphicon glyphicon-leaf green" style="font-size: 26px;"></i> PORTAL SDR</h1>

                                <a href='https://www.portalsdr.ba.gov.br/' target='_blank' >
                                    <p><b>SDR</b> - Secretaria de Desenvolvimento Rural</p>
                                </a>
                            </div>
                        </div>
                    </form>
                    <!-- form -->
                </section>
                <!-- content -->
            </div>

        </div>
    </div>

</body>
<?php include '../template/_end.php'; ?>