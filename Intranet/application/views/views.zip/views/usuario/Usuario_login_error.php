<?php include '../template/begin_semvalidacao_sem_menu.php'; ?> 


<body style="background:#F7F7F7;">

    <div class="">
        <a class="hiddenanchor" id="toregister"></a>
        <a class="hiddenanchor" id="tologin"></a>
        <div id="wrapper">
            <div id="login" class="animate form">
                <section class="login_content"> 
                     <?php echo 'error'?>
                </section> 
            </div>

        </div>
    </div>

</body>
<?php include '../template/_end.php'; ?>