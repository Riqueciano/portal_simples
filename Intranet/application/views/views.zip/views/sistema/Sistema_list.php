<?php  include '../template/_begin_intranet.php';
 
?> 
<html>
    <head>
        <title>SDR</title>
        <!--link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/-->
        <style>

        </style>
    </head>
    <body>
        <h2 style="margin-top:0px"></h2>

        <div style='overflow-x:auto'>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12"> 
                    <div  class="col-md-12">
                        <div class="x_panel" id=''>
                            <div class="x_title" style=" background-color: ">
                                <div class="col-md-10"  >
                                    <p style='cursor: pointer'><i class="glyphicon glyphicon-leaf" > </i> <b>Bem vindo(a), <?=$pessoa_nm_temp." ($usuario_login)"?></b></p>
                                </div>
                                <a href='<?=site_url('Usuario/acao_usuario_muda_senha')?>'>
                                    <div class="col-md-2 rigth" style='cursor:pointer'>
                                        <p class="text-right" ><i class="fa fa-key" style='color: orangered'> </i> <b>Renovar Senha</b></p>
                                    </div>
                                </a>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <div style='overflow-x:auto'>
                                    <div class="bs-glyphicons">
                                        
                                        <ul class="bs-glyphicons-list">
                                            <?php foreach ($sistema_data as $sistema) { ?>
                                                <li>
                                                    <?php echo '<a href="' . site_url('/usuario/select_sistema/?sistema='.$sistema->sistema_id).'' . '">' ?>
                                                    <span class="glyphicon-class">
                                                        <!--i class="fa fa-soccer-ball-o" style="font-size:50px"></i-->
                                                        <?php //echo '<img style="width:55px" src="https://portalsdr.ba.gov.br/_portal/Icones/' . $sistema->sistema_icone  . '" alt="' . $sistema->sistema_nm . '" border="0"></a> '; ?>
                                                        <?php echo '<img style="width:55px" src="https://'.$_SERVER['HTTP_HOST'].'/'.$_SESSION['pasta_sistema_pai'].'/Icones/'.$sistema->sistema_icone    . '" alt="' . $sistema->sistema_nm . '" border="0"></a> '; ?>
                                                    </span>
                                                    <span class="" aria-hidden="true"><b><?= $sistema->sistema_nm ?></b></span>
                                                    <?php echo '</a>' ?>
                                                </li>
                                            <?php }
                                            ?>
                                        </ul>
                                    </div>          
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="row" style="margin-bottom: 10px">
                <div class="col-md-4">

                </div>
                <div class="col-md-3 text-center">
                    <div style="margin-top: 8px" id="message">
                        <?php //echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                    </div>
                </div>
                <div class="col-md-1 text-right">
                </div>
                <div class="col-md-4 text-right">
                    <form action="<?php echo site_url('sistema/index'); ?>" class="form-inline" method="get">
                        <div class="input-group">
                            <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                            <span class="input-group-btn">
                                <?php
                                if ($q <> '') {
                                    ?>
                                    <a href="<?php echo site_url('sistema'); ?>" class="btn btn-default">X</a>
                                    <?php
                                }
                                ?>
                                <button class="btn btn-primary" type="submit">Procurar</button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </body>
</html>
<?php include '../template/_end.php'; ?>