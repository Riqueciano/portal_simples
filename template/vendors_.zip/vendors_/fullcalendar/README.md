# FullCalendar

A full-sized drag & drop event calendar (jQuery plugin).

- [Project website and demos](https://fullcalendar.io/)
- [Documentation](https://fullcalendar.io/docs/)
- [Support](https://fullcalendar.io/support/)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)
- [License](LICENSE.txt)