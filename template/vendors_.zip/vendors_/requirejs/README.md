# requirejs-bower

Bower packaging for [RequireJS](https://requirejs.org).

